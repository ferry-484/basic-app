import logo from './logo.svg';
import './App.css';
import Child from './Child';
import Routes from './Routes';
import Header from './Header';
function App() {
const data= {"name":"rajeev"};
  return (
    <>
      <Routes />
      
    
    {/* <h1>This is a dummy</h1>
    
    <Child /> */}


    

    
  
    
    </>
    
  );
}


export default App;


